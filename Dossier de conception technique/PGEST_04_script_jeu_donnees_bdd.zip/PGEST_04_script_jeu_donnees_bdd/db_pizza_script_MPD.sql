
CREATE SEQUENCE public.adresse_id_seq;

CREATE TABLE public.adresse (
                id INTEGER NOT NULL DEFAULT nextval('public.adresse_id_seq'),
                numero INTEGER NOT NULL,
                rue VARCHAR(150) NOT NULL,
                codePostal INTEGER NOT NULL,
                ville VARCHAR(100) NOT NULL,
                CONSTRAINT adresse_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.adresse_id_seq OWNED BY public.adresse.id;

CREATE SEQUENCE public.pizzeria_id_seq;

CREATE TABLE public.pizzeria (
                id INTEGER NOT NULL DEFAULT nextval('public.pizzeria_id_seq'),
                nom VARCHAR(100) NOT NULL,
                adresse_id INTEGER NOT NULL,
                CONSTRAINT pizzeria_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.pizzeria_id_seq OWNED BY public.pizzeria.id;

CREATE SEQUENCE public.ingredient_id_seq;

CREATE TABLE public.ingredient (
                id INTEGER NOT NULL DEFAULT nextval('public.ingredient_id_seq'),
                nom VARCHAR(50) NOT NULL,
                CONSTRAINT ingredient_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.ingredient_id_seq OWNED BY public.ingredient.id;

CREATE TABLE public.stock (
                id_ingredient INTEGER NOT NULL,
                id_pizzeria INTEGER NOT NULL,
                quantite INTEGER NOT NULL,
                CONSTRAINT stock_pk PRIMARY KEY (id_ingredient, id_pizzeria)
);


CREATE SEQUENCE public.pizza_id_seq;

CREATE TABLE public.pizza (
                id INTEGER NOT NULL DEFAULT nextval('public.pizza_id_seq'),
                nom VARCHAR(50) NOT NULL,
                prixHt DOUBLE PRECISION NOT NULL,
                recette TEXT NOT NULL,
                tva100 DOUBLE PRECISION NOT NULL,
                CONSTRAINT pizza_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.pizza_id_seq OWNED BY public.pizza.id;

CREATE TABLE public.pizza_ingredient (
                id_pizza INTEGER NOT NULL,
                id_ingredient INTEGER NOT NULL,
                quantite INTEGER NOT NULL,
                CONSTRAINT pizza_ingredient_pk PRIMARY KEY (id_pizza, id_ingredient)
);


CREATE SEQUENCE public.utilisateur_id_seq;

CREATE TABLE public.utilisateur (
                id INTEGER NOT NULL DEFAULT nextval('public.utilisateur_id_seq'),
                nom VARCHAR(100) NOT NULL,
                prenom VARCHAR(100) NOT NULL,
                mot_de_passe VARCHAR(20) NOT NULL,
                mail VARCHAR(100) NOT NULL,
                CONSTRAINT utilisateur_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.utilisateur_id_seq OWNED BY public.utilisateur.id;

CREATE SEQUENCE public.personnel_id_seq;

CREATE TABLE public.personnel (
                id INTEGER NOT NULL DEFAULT nextval('public.personnel_id_seq'),
                fonction VARCHAR NOT NULL,
                id_pizzeria INTEGER NOT NULL,
                CONSTRAINT personnel_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.personnel_id_seq OWNED BY public.personnel.id;

CREATE SEQUENCE public.client_id_seq;

CREATE TABLE public.client (
                id INTEGER NOT NULL DEFAULT nextval('public.client_id_seq'),
                telephone INTEGER NOT NULL,
                adresse_id INTEGER NOT NULL,
                CONSTRAINT client_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.client_id_seq OWNED BY public.client.id;

CREATE SEQUENCE public.panier_id_seq;

CREATE TABLE public.panier (
                id INTEGER NOT NULL DEFAULT nextval('public.panier_id_seq'),
                paiement BOOLEAN NOT NULL,
                prixHt DOUBLE PRECISION NOT NULL,
                tva100 DOUBLE PRECISION NOT NULL,
                id_client INTEGER NOT NULL,
                CONSTRAINT panier_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.panier_id_seq OWNED BY public.panier.id;

CREATE TABLE public.panier_pizza (
                id_panier INTEGER NOT NULL,
                id_pizza INTEGER NOT NULL,
                quantite INTEGER NOT NULL,
                CONSTRAINT panier_pizza_pk PRIMARY KEY (id_panier, id_pizza)
);


CREATE SEQUENCE public.commande_id_seq;

CREATE TABLE public.commande (
                id INTEGER NOT NULL DEFAULT nextval('public.commande_id_seq'),
                paiement  BOOLEAN NOT NULL,
                etat VARCHAR(20) NOT NULL,
                date DATE,
                id_panier INTEGER NOT NULL,
                id_personnel INTEGER NOT NULL,
                CONSTRAINT commande_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.commande_id_seq OWNED BY public.commande.id;

CREATE SEQUENCE public.paiement_id_seq;

CREATE TABLE public.paiement (
                id INTEGER NOT NULL DEFAULT nextval('public.paiement_id_seq'),
                typePaiement VARCHAR(20) NOT NULL,
                id_commande INTEGER NOT NULL,
                date DATE,
                paiement BOOLEAN NOT NULL,
                CONSTRAINT paiement_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.paiement_id_seq OWNED BY public.paiement.id;

CREATE SEQUENCE public.livraison_id_seq;

CREATE TABLE public.livraison (
                id INTEGER NOT NULL DEFAULT nextval('public.livraison_id_seq'),
                date DATE,
                id_client INTEGER NOT NULL,
                id_commande INTEGER NOT NULL,
                CONSTRAINT livraison_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.livraison_id_seq OWNED BY public.livraison.id;

ALTER TABLE public.client ADD CONSTRAINT adresse_client_fk
FOREIGN KEY (adresse_id)
REFERENCES public.adresse (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizzeria ADD CONSTRAINT adresse_pizzeria_fk
FOREIGN KEY (adresse_id)
REFERENCES public.adresse (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock ADD CONSTRAINT pizzeria_stock_fk
FOREIGN KEY (id_pizzeria)
REFERENCES public.pizzeria (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.personnel ADD CONSTRAINT pizzeria_personnel_fk
FOREIGN KEY (id_pizzeria)
REFERENCES public.pizzeria (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizza_ingredient ADD CONSTRAINT ingredient_pizza_ingredient_fk
FOREIGN KEY (id_ingredient)
REFERENCES public.ingredient (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock ADD CONSTRAINT ingredient_stock_fk
FOREIGN KEY (id_ingredient)
REFERENCES public.ingredient (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizza_ingredient ADD CONSTRAINT pizza_pizza_ingredient_fk
FOREIGN KEY (id_pizza)
REFERENCES public.pizza (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.panier_pizza ADD CONSTRAINT pizza_panier_pizza_fk
FOREIGN KEY (id_pizza)
REFERENCES public.pizza (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.client ADD CONSTRAINT user_client_fk
FOREIGN KEY (id)
REFERENCES public.utilisateur (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.personnel ADD CONSTRAINT user_personnel_fk
FOREIGN KEY (id)
REFERENCES public.utilisateur (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.commande ADD CONSTRAINT personnel_commande_fk
FOREIGN KEY (id_personnel)
REFERENCES public.personnel (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.livraison ADD CONSTRAINT client_livraison_fk
FOREIGN KEY (id_client)
REFERENCES public.client (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.panier ADD CONSTRAINT client_panier_fk
FOREIGN KEY (id_client)
REFERENCES public.client (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.commande ADD CONSTRAINT panier_commande_fk
FOREIGN KEY (id_panier)
REFERENCES public.panier (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.panier_pizza ADD CONSTRAINT panier_panier_pizza_fk
FOREIGN KEY (id_panier)
REFERENCES public.panier (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.livraison ADD CONSTRAINT commande_livraison_fk
FOREIGN KEY (id_commande)
REFERENCES public.commande (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.paiement ADD CONSTRAINT commande_paiement_fk
FOREIGN KEY (id_commande)
REFERENCES public.commande (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;
